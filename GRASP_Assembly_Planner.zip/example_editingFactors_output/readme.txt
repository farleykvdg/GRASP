Find a copy of all .gb files required for assembly in 'part_records' 
Find all level 0 and level 1 assemblies in 'all_construct_records'