GRASP Assembly Planner (GAP) v0.5

Create GRASP PPRs and an assembly plan from your targets.
- Single-target or .fasta input 
- 9, 14, or 19 motif binding or editing GRASP PPR proteins 
- in silico assembly and organisation with DNAcauldron (https://github.com/Edinburgh-Genome-Foundry/DnaCauldron)
- Fully customisable - simply edit a spreadsheet input and provide the plasmid files to `GRASP_Seqs` to create your own constructs

Requirements: pandas, csv, dnacauldron

Usage:
Extract and run `GRASP_assembly_planner_v##.py`. Keep `GRASP_Seqs` in the same location, or edit line 371 to redirect.
If you wish to use non-GRASP plasmids in your assembly, place them in this folder in genbank format.
The program is guided, and takes an input of one target or a .fasta format file with multiple.
The user can input 9, 14, or 19-base targets to create 9, 14, or 19-motif binding PPRs. 
16, 21, or 26-base targets create 9, 14, or 19-motif editing factors with a choice of S2 motif. 
Currently, inputs can only contain targets of ONE type (e.g. they must all be 16 bases long).

The following functions are available:
1: Create a DNAcauldron-compatible spreadsheet, and use it to create an assembly plan. DNAcauldron automatically performs in silico assembly; it will assemble pPR0 parts automatically, and pPR1 in the case of editing factors. Restriction enzymes are chosen automatically.
2: Create a DNAcauldron spreadsheet, but not an assembly plan. Prepares a plan for GRASP motif pPR0 assembly and leaves space for the insertion of custom parts.
3: Prepare an assembly plan from an existing spreadsheet (use after function 2)
4: Print a basic plan to console/.txt without DNAcauldron. Gives a quick idea of how your pPR0 assemblies will look.
5: Simple explanation of how the targets are delimited 

Examples:
Two .fasta files of 9-motif binding and editing factors are included, as well as the spreadsheet and Assembly Plan outputs.